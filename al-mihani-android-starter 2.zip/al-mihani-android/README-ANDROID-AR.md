# المهني - تجهيز أندرويد

هذا المجلد يضم نسخة الويب الأصلية داخل `www/index.html` وإعدادات Capacitor 7.

## إنشاء مشروع أندرويد

```bash
npm install
npx cap add android
npx cap sync android
```

## البناء التجريبي

```bash
cd android
./gradlew bundleRelease
```

الناتج يكون عادةً داخل:
`android/app/build/outputs/bundle/release/app-release.aab`

ملاحظة: ملف AAB الناتج يحتاج توقيع Release بمفتاح Keystore قبل رفعه إلى Google Play. لا ترفع مفاتيح التوقيع أو كلمات المرور إلى GitHub.

معرّف التطبيق الحالي: `iq.almihani.app` ويمكن تغييره قبل أول نشر إذا رغبت.
